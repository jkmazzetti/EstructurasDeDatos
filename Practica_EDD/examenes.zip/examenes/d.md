Evaluación D - 24/11/2020
Evaluación de Estructura de Datos- UNTREF

# 1
Dado el siguiente archivo csv con datos de registros de temperatura del último año provisto por el Servicio Metereológico Nacional, Donde en cada línea se tienen los siguientes datos: Fecha, temperatura máxima, temperatura mínima, estación meteorológica. Se pide generar un archivo json denominado temperaturas.json con el siguiente formato: {"anio": {"tmax_promedio": temperatura_max_promedio_anual, "tmin_promedio": temperatura_min_promedio_anual}, "ene": {"tmax_promedio": temperatura_max_promedio_mensual, "tmin_promedio": temperatura_min_promedio_mensual}, "feb": {"tmax_promedio": temperatura_max_promedio_mensual, "tmin_promedio": temperatura_min_promedio_mensual} ...}. Subir archivo .zip con la solución completa


# 2
El siguiente archivo tiene una lista de algunas materias de varios departamentos de la Universidad de Stanford. Escribir las expresiones XPATH que permitan. 1) Listar los títulos de las materias del departamento "Computer Science" 2) Todas las materias que dicta el profesor de Apellido Roberts 3)Todas las materias que tienen como correlativas a alguna de las materias que dicta el profesor de Apellido Roberts
https://drive.google.com/file/d/1GkukWhWZXMDg1wxYOYeLzEQyejPlSRfT/view?usp=sharing

# 3 

Describir la técnica BlockStorage para comprimir un diccionario de términos. (a) Aplicarla al siguiente caso: Tamaño del bloque = 6, contenidos = ["conjeturar", "conjugación", "conjugar", "conjunción","conjuntado", "conjuntamente", "conjuntar", "conjuntero", "conjuntivitis", "conjuntivo", "conjunto","conjura", "conjurado", "conjurar", "conjuro", "conllevar", "conmemoración", "conmemorar","conmemorativo", "conmigo”]. (b) Aplicar compresión a la lista de apariciones del término “conjugar”suponiendo que aparece en los documentos 1000566, 1000601, 1000690, 1000720.
Archivos enviados

# 4 
Escribir las siguientes expresiones regulares. 1) Que acepte palíndromos(palabras que se leen igual desde adelante hacia atrás y desde atrás hacia adelante) de longitud menor o igual a 5. Ejemplo debe aceptar: rotor, ala, solos, y rechazar neuquen, el le (porque son dos palabras)  2) Números enteros y en punto flotante, incluyendo notación científica. Debería aceptar, por ejemplo, "1", "-1", "+15", "1.55", ".5", "5.", "1.3e2", "1E-4", "1e+12" y rechazar "1a", "+-1", "1.2.3", "1+1", "1e4.5", ".5.", 1f5, "."