import csv
import json


class AnalizarArchivo:
    def __init__(self,archivo):
        self.archivo=archivo
        self.dict_salida={}
    def leerArchivo(self):
        try:
            with open(self.archivo,"r") as doc:
                reader=csv.DictReader(doc)
                for fila in reader:
                    anio=fila["fecha"].split("-")[0]
                    mes=self.__convertirMesEntero(fila["fecha"].split("-")[1])
                    valido=fila["valido"]
                    if valido=="true":
                        cotizacion=fila["tipo_cambio_bna_vendedor"]
                    self.__cargarDiccionario(anio,mes,float(cotizacion))
        except FileNotFoundError as e:
            print("No se encontró el archivo.")

    def __convertirMesEntero(self,mes):
        if mes[0]=="0":
            mes=mes[1]
        return int(mes)-1

    def __cargarDiccionario(self,anio,mes,cotizacion):
        lista_meses=["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"]
        if anio not in self.dict_salida.keys():
            dict_prom_mensual={"promedio mensual":{}}
            dict_prom_mensual.get("promedio mensual")[lista_meses[mes]]=cotizacion
            self.dict_salida[anio] = {"promedio anual":cotizacion,
                                      "promedio mensual": dict_prom_mensual.get("promedio mensual")}
        else:
            if self.dict_salida.get(anio).get("promedio mensual").get(lista_meses[mes])!=None:
                promedio_m=round((self.dict_salida.get(anio).get("promedio mensual").get(lista_meses[mes])+cotizacion)/2,2)
                self.dict_salida.get(anio).get("promedio mensual")[lista_meses[mes]] = promedio_m
            else:
                self.dict_salida.get(anio).get("promedio mensual")[lista_meses[mes]]=cotizacion
            promedio_a = round((self.dict_salida.get(anio).get("promedio anual") + cotizacion) / 2, 2)
            self.dict_salida.get(anio)["promedio anual"]=promedio_a

    def escribirArchivo(self):
        with open("dolar.json","w") as doc:
            json.dump(self.dict_salida,doc)

if __name__ == '__main__':
    procesarCSV=AnalizarArchivo("datos-tipo-cambio-usd-futuro-dolar-frecuencia-diaria.csv")
    procesarCSV.leerArchivo()
    procesarCSV.escribirArchivo()








