import csv
import json


class ProcesadorCSV:
    def __init__(self,archivo):
        self.dict_salida={"posiciones":{}}
        self.archivo=archivo
    def leerArchivo(self):
        with open(self.archivo,"r") as doc:
            lector=csv.DictReader(doc)
            for fila in lector:
                favor=int(fila["Goles Local"])
                contra=int(fila["Goles Visitante"])
                equipo=fila["Local"]
                self.__cargarDiccionario(favor,contra,equipo)
    def __cargarDiccionario(self,favor,contra,equipo):
        puntos=self.__calcularPuntos(favor,contra)
        if equipo not in self.dict_salida.get("posiciones").keys():
            self.dict_salida.get("posiciones")[equipo]={"puntos":puntos,"goles a favor":favor,"goles en contra":contra}
        else:
            g_favor=self.dict_salida.get("posiciones").get(equipo).get("goles a favor")+favor
            g_contra=self.dict_salida.get("posiciones").get(equipo).get("goles en contra")+contra
            p=self.dict_salida.get("posiciones").get(equipo).get("puntos")+puntos
            self.dict_salida.get("posiciones")[equipo] = {"puntos": p, "goles a favor": g_favor,"goles en contra": g_contra}
    def __calcularPuntos(self,favor,contra):
        if favor>contra:
            puntos=3
        elif favor<contra:
            puntos=0
        else:
            puntos=1
        return puntos
    def escribirArchivo(self):
        with open("campeonato.json","w") as doc:
            json.dump(self.dict_salida,doc)

if __name__ == '__main__':
    procesar=ProcesadorCSV("liga_espana.csv")
    procesar.leerArchivo()
    procesar.escribirArchivo()