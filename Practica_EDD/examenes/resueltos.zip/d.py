import csv
import json


class ProcesadorCSV:
    def __init__(self, archivo):
        self.archivo = archivo
        self.dict_salida = {}
        self.contizacion_actual = 0

    def procesarDatos(self):
        try:
            with open(self.archivo, "r") as contenido:
                lectura = csv.DictReader(contenido)
                for fila in lectura:
                    anio = fila["FECHA"].split("/")[2]
                    mes = self.convertir_mes_entero(fila["FECHA"].split("/")[1])
                    if fila["TMIN"]!="" and fila["TMAX"]!="":
                        tmin = float(fila["TMIN"])
                        tmax = float(fila["TMAX"])
                    self.__construirDiccionarios(anio, mes, tmin, tmax)
        except FileNotFoundError as e:
            print("No se encontró el archivo")

    def __construirDiccionarios(self, anio, mes, tmin, tmax):
        lista_meses = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]
        if anio not in self.dict_salida.keys():
            self.dict_salida[anio] = {"tmin_promedio": tmin, "tmax_promedio": tmax}
            for i in range(len(lista_meses)):
                if i !=mes:
                    self.dict_salida.get(anio)[lista_meses[i]]={"tmax_promedio":None,"tmin_promedio":None}
                else:
                    self.dict_salida.get(anio)[lista_meses[i]] = {"tmax_promedio": tmax,"tmin_promedio":tmin}
        else:
            if self.dict_salida.get(anio).get(lista_meses[mes]).get("tmax_promedio")!=None:
                p_max_mensual = round((self.dict_salida.get(anio).get(lista_meses[mes]).get("tmax_promedio") + tmax) / 2,
                                     2)
                p_min_mensual = round((self.dict_salida.get(anio).get(lista_meses[mes]).get("tmin_promedio") + tmin) / 2,
                                     2)
                self.dict_salida.get(anio)[lista_meses[mes]]={"tmax_promedio":p_max_mensual,"tmin_promedio":p_min_mensual}
            else:
                self.dict_salida.get(anio)[lista_meses[mes]] = {"tmax_promedio": tmax,"tmin_promedio":tmin}

            p_max_anual= round((self.dict_salida.get(anio).get("tmax_promedio")+tmax)/2,2)
            p_min_anual = round((self.dict_salida.get(anio).get("tmin_promedio")+tmin)/2,2)
            self.dict_salida.get(anio)["tmin_promedio"] = p_max_anual
            self.dict_salida.get(anio)["tmax_promedio"] = p_min_anual


    def escribirjson(self):
        with open("temperatura.json", "w") as escritor:
            json.dump(self.dict_salida, escritor)

    def convertir_mes_entero(self, mes):
        if mes[0] == 0:
            mes = mes[1]
        return int(mes) - 1


if __name__ == '__main__':
    procesar = ProcesadorCSV("temperatura.csv")
    procesar.procesarDatos()
    procesar.escribirjson()
