import csv
import operator
import string
import unicodedata
from abc import ABC, abstractmethod
from datetime import datetime
from scrapy.crawler import CrawlerProcess

from TP_Supermercados.TP_Supermercados.spiders.dia import DiaSpider
from TP_Supermercados.TP_Supermercados.spiders.jumbo import JumboSpider
from TP_Supermercados.TP_Supermercados.spiders.laamistad import LaamistadSpider
from TP_Supermercados.TP_Supermercados.spiders.walmart import WalmartSpider


class Buscador(ABC):

    def __init__(self, busqueda, formato):
        self.busqueda = self.formatear(busqueda)
        self.tipo_busqueda = ''
        self.date = str(datetime.now().date())
        self.ruta_destino = 'Salida/' + self.busqueda.replace(' ', '_') + '_' + self.date + '.' + formato
        self.formato = formato
        self.process = CrawlerProcess({
            'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/86.0.4240.111 Safari/537.36',
            'FEED_EXPORT_FIELDS': ['fecha_de_extraccion', 'precio', 'producto', 'marca', 'supermercado', 'categoria',
                                   'link', 'hora'],
            'FEED_EXPORT_ENCODING': 'utf-8',
            'FEED_FORMAT': formato,
            'FEED_URI': self.ruta_destino
        })

    def iniciar_busqueda(self):
        urls, reglas = self.generar_url_reglas()
        laamistad_start = urls[0]
        laamistad_rules = reglas[0]
        jumbo_start = urls[1]
        jumbo_rules = reglas[1]
        dia_start = urls[2]
        dia_rules = reglas[2]
        walmart_start = urls[3]
        walmart_rules = reglas[3]
        self.process.crawl(JumboSpider, start_urls=jumbo_start, rules=jumbo_rules)
        self.process.crawl(LaamistadSpider, start_urls=laamistad_start, rules=laamistad_rules)
        self.process.crawl(DiaSpider, start_urls=dia_start, rules=dia_rules)
        self.process.crawl(WalmartSpider, start_urls=walmart_start, rules=walmart_rules)
        self.process.start()

    @abstractmethod
    def generar_url_reglas(self):
        pass

    def generar_archivo_ordenado_por_menor_precio(self):
        try:
            if self.formato == 'csv':
                with open(self.ruta_destino, 'r') as file:
                    reader = csv.DictReader(file)
                    unsorted_dict = {}
                    for fila in reader:
                        supermercado = fila['supermercado']
                        marca = fila['marca']
                        producto = fila['producto']
                        categoria = fila['categoria']
                        hora = fila['hora']
                        precio = fila['precio']
                        link = fila['link']
                        fecha_de_extraccion = fila['fecha_de_extraccion']
                        lista = [fecha_de_extraccion, producto, marca, supermercado, categoria, link, hora]
                        precio = precio.replace(" ", "").replace("$", "").replace(",", ".")
                        if precio != 'precio' and precio != 'xkg' and precio != '' and precio.count('.') == 1:
                            precio = float(precio)
                            if precio not in unsorted_dict.keys():
                                unsorted_dict[precio] = [lista]
                            else:
                                list_aux = []
                                for lista_rec in unsorted_dict.get(precio):
                                    list_aux.append(lista_rec)
                                list_aux.append(lista)
                                unsorted_dict[precio] = list_aux
                    sorted_dict = dict(sorted(unsorted_dict.items(), key=operator.itemgetter(0)))
                    with open(self.ruta_destino, 'w', newline="") as archivo:
                        campos_archivo = ['fecha_de_extraccion', 'precio', 'producto', 'marca', 'supermercado',
                                          'categoria', 'link', 'hora']
                        writer = csv.DictWriter(archivo, fieldnames=campos_archivo)
                        writer.writeheader()
                        for precio in sorted_dict.keys():
                            for lista in sorted_dict.get(precio):
                                writer.writerow({campos_archivo[0]: lista[0], campos_archivo[1]: precio,
                                                 campos_archivo[2]: lista[1],
                                                 campos_archivo[3]: lista[2], campos_archivo[4]: lista[3],
                                                 campos_archivo[5]: lista[4],
                                                 campos_archivo[6]: lista[5], campos_archivo[7]: lista[6]})
        except FileNotFoundError as e:
            print('No se encontró el archivo.')
        except ValueError as e:
            print('Hubo incompatibilidad datos.\nPuede que la pagina haya cambiado.')

    def formatear(self, busqueda):
        busqueda = ''.join((c for c in unicodedata.normalize('NFD', busqueda) if unicodedata.category(c) != 'Mn'))
        for char in string.punctuation + "¡¿":
            busqueda = busqueda.replace(char, '')
        return busqueda.lower()
