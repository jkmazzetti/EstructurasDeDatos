from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor

from TP_Supermercados.TP_Supermercados.Buscador.Buscador import Buscador
from TP_Supermercados.TP_Supermercados.spiders.dia import DiaSpider
from TP_Supermercados.TP_Supermercados.spiders.jumbo import JumboSpider
from TP_Supermercados.TP_Supermercados.spiders.laamistad import LaamistadSpider
from TP_Supermercados.TP_Supermercados.spiders.walmart import WalmartSpider


class BuscadorExacto(Buscador):

    def __init__(self, busqueda, formato):
        super(BuscadorExacto, self).__init__(busqueda, formato)
        self.tipo_busqueda='exacto'

    def generar_url_reglas(self):
        DiaSpider.busqueda = self.busqueda
        JumboSpider.busqueda = self.busqueda
        WalmartSpider.busqueda = self.busqueda
        LaamistadSpider.busqueda = self.busqueda
        dia_start = ['https://diaonline.supermercadosdia.com.ar/buscapagina?ft=' + self.busqueda.replace(' ', '-') +
                     '&PS=50&sl=c75a25d1-e00f-4d28-938f-c6c4d16cfd74&cc=4&sm=0&PageNumber=1']
        dia_rules = [Rule(LinkExtractor(allow=r'' + self.busqueda.replace(' ', '-')), callback=self.tipo_busqueda)]

        jumbo_start = ['https://www.jumbo.com.ar/buscapagina?sl=1579df47-6ea5-4570-a858-8067a35362be&PS=200&cc=18&sm=0'
            '&PageNumber=1&&&ft=' + self.busqueda.replace(' ', '+') + '&O=OrderByScoreDESC']
        jumbo_rules= [Rule(LinkExtractor(allow=r'/'), callback=self.tipo_busqueda)]
        laamistad_start = ['https://www.tiendalaamistad.com.ar/?s=' + self.busqueda.replace(' ', '+')]
        laamistad_rules = [Rule(LinkExtractor(allow=r'page/')),
                           Rule(LinkExtractor(allow=r'tienda/'), callback=self.tipo_busqueda)]
        walmart_start = [
            'https://www.walmart.com.ar/buscapagina?sl=63c6cac5-a4b5-4191-a52a-65582db8f8b3&PS=48&cc=50&PageNumber=1&O'
            '=OrderByReviewRateDESC&sm=0&ft=' + self.busqueda.replace(' ', '+') + '&sc=15']
        walmart_rules = [Rule(LinkExtractor(allow=r'-'), callback=self.tipo_busqueda)]

        urls = [laamistad_start, jumbo_start, dia_start, walmart_start]
        reglas = [laamistad_rules, jumbo_rules, dia_rules, walmart_rules]
        return urls, reglas
