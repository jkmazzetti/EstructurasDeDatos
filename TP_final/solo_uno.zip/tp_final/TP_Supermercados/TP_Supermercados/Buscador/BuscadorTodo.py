from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor

from TP_Supermercados.TP_Supermercados.Buscador.BuscadorVariable import BuscadorVariable
from TP_Supermercados.TP_Supermercados.spiders.dia import DiaSpider
from TP_Supermercados.TP_Supermercados.spiders.jumbo import JumboSpider
from TP_Supermercados.TP_Supermercados.spiders.laamistad import LaamistadSpider
from TP_Supermercados.TP_Supermercados.spiders.walmart import WalmartSpider


class BuscadorTodo(BuscadorVariable):

    def __init__(self, busqueda, formato):
        super(BuscadorTodo, self).__init__(busqueda, formato)
        self.tipo_busqueda = 'todo'

    def generar_url_reglas(self):
        DiaSpider.busqueda = self.quitar_stopwords(self.busqueda)
        JumboSpider.busqueda = self.quitar_stopwords(self.busqueda)
        WalmartSpider.busqueda = self.quitar_stopwords(self.busqueda)
        LaamistadSpider.busqueda = self.quitar_stopwords(self.busqueda)
        self.busqueda = self.busqueda.split(' ')[0]
        laamistad_start = []
        jumbo_start = []
        dia_start = []
        walmart_start = []
        laamistad_rules = [Rule(LinkExtractor(allow=r'page/')),
                           Rule(LinkExtractor(allow=r'tienda/'), callback=self.tipo_busqueda)]

        walmart_rules = [Rule(LinkExtractor(allow=r'-'), callback=self.tipo_busqueda)]
        dia_rules = []
        jumbo_rules = []

        laamistad_start.append('https://www.tiendalaamistad.com.ar/?s=' + self.busqueda)
        jumbo_start.append(
            'https://www.jumbo.com.ar/buscapagina?sl=1579df47-6ea5-4570-a858-8067a35362be&PS=200&cc=18&sm=0'
            '&PageNumber=1&&&ft=' + self.busqueda.replace(' ', '+') + '&O=OrderByScoreDESC')
        dia_start.append(
            'https://diaonline.supermercadosdia.com.ar/buscapagina?ft=' + self.busqueda.replace(' ', '-') +
            '&PS=50&sl=c75a25d1-e00f-4d28-938f-c6c4d16cfd74&cc=4&sm=0&PageNumber=1')
        walmart_start.append(
            'https://www.walmart.com.ar/buscapagina?sl=63c6cac5-a4b5-4191-a52a-65582db8f8b3&PS=48&cc'
            '=50&PageNumber=1&O=OrderByReviewRateDESC&sm=0&ft= ' + self.busqueda.replace(' ',
                                                                                         '+') + '&sc=15')
        dia_rules.append(Rule(LinkExtractor(allow=r'' + self.busqueda), callback=self.tipo_busqueda))
        jumbo_rules.append(Rule(LinkExtractor(allow=r'' + self.busqueda), callback=self.tipo_busqueda))

        urls = [laamistad_start, jumbo_start, dia_start, walmart_start]
        reglas = [laamistad_rules, jumbo_rules, dia_rules, walmart_rules]
        return urls, reglas
