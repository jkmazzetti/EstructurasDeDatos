import csv
import pytest

#Se recomienda eliminar archivos dentro de la carpeta salida antes de correr los tests y
#ejecutar de a uno por vez.
from TP_Supermercados.TP_Supermercados.Buscador.BuscadorExacto import BuscadorExacto
from TP_Supermercados.TP_Supermercados.Buscador.BuscadorVariable import BuscadorVariable
from TP_Supermercados.TP_Supermercados.spiders.dia import DiaSpider
from TP_Supermercados.TP_Supermercados.spiders.jumbo import JumboSpider
from TP_Supermercados.TP_Supermercados.spiders.laamistad import LaamistadSpider
from TP_Supermercados.TP_Supermercados.spiders.walmart import WalmartSpider


def test_formatear():
    prueba = '¿¡Esto debería no contener acentos, signos de puntuación y estar en MinúsculA...!?'
    assert BuscadorExacto.formatear(BuscadorExacto,prueba) == 'esto deberia no contener acentos signos de puntuacion y estar en minuscula'

def test_quitar_stopwords():
    prueba = "Todos los dias suelo salir a caminar aunque sea media hora."
    assert BuscadorVariable.quitar_stopwords(BuscadorVariable,
                                                              prueba) == "Todos dias suelo salir caminar aunque media hora."

#Los test aquí presentados pasan las pruebas pero eso NO significa que para todos los casos suceda lo mismo.

def test_busqueda_exacta_jumbo():
    busqueda='Hilo Dental Gum Encerado Sabor Menta'
    busqueda_exacta=busqueda
    busqueda = BuscadorExacto.formatear(BuscadorExacto,busqueda)
    DiaSpider.busqueda = busqueda
    JumboSpider.busqueda = busqueda
    WalmartSpider.busqueda = busqueda
    LaamistadSpider.busqueda = busqueda
    nuevo_buscador = BuscadorExacto(busqueda, 'csv')
    nuevo_buscador.iniciar_busqueda()
    nuevo_buscador.generar_archivo_ordenado_por_menor_precio()
    with open(nuevo_buscador.ruta_destino, 'r') as file:
        reader = csv.DictReader(file)
        for fila in reader:
            producto = fila['producto']
    assert producto == busqueda_exacta

def test_busqueda_exacta_dia():
    busqueda='Provenzal DIA 50 Gr.'
    busqueda_exacta = busqueda
    busqueda = BuscadorExacto.formatear(BuscadorExacto,busqueda)
    DiaSpider.busqueda = busqueda
    JumboSpider.busqueda = busqueda
    WalmartSpider.busqueda = busqueda
    LaamistadSpider.busqueda = busqueda
    nuevo_buscador = BuscadorExacto(busqueda, 'csv')
    nuevo_buscador.iniciar_busqueda()
    nuevo_buscador.generar_archivo_ordenado_por_menor_precio()
    with open(nuevo_buscador.ruta_destino, 'r') as file:
        reader = csv.DictReader(file)
        for fila in reader:
            producto = fila['producto']
    assert producto == busqueda_exacta

def test_busqueda_exacta_walmart():
    busqueda='Tostadas Integrales Great Value 200gr'
    busqueda_exacta=busqueda
    busqueda = BuscadorExacto.formatear(BuscadorExacto,busqueda)
    DiaSpider.busqueda = busqueda
    JumboSpider.busqueda = busqueda
    WalmartSpider.busqueda = busqueda
    LaamistadSpider.busqueda = busqueda
    nuevo_buscador = BuscadorExacto(busqueda, 'csv')
    nuevo_buscador.iniciar_busqueda()
    nuevo_buscador.generar_archivo_ordenado_por_menor_precio()
    with open(nuevo_buscador.ruta_destino, 'r') as file:
        reader = csv.DictReader(file)
        for fila in reader:
            producto = fila['producto']
    assert producto == busqueda_exacta

def test_busqueda_exacta_la_amistad():
    busqueda='NATUZEN HARINA DE ARROZ 1 KG'
    busqueda_exacta=busqueda
    busqueda = BuscadorExacto.formatear(BuscadorExacto,busqueda)
    DiaSpider.busqueda = busqueda
    JumboSpider.busqueda = busqueda
    WalmartSpider.busqueda = busqueda
    LaamistadSpider.busqueda = busqueda
    nuevo_buscador = BuscadorExacto(busqueda, 'csv')
    nuevo_buscador.iniciar_busqueda()
    nuevo_buscador.generar_archivo_ordenado_por_menor_precio()
    with open(nuevo_buscador.ruta_destino, 'r') as file:
        reader = csv.DictReader(file)
        for fila in reader:
            producto = fila['producto']
    assert producto == busqueda_exacta

#Se omitieron los test de busqueda por palabra o con todas las palabras por las razones antes mencionadas. De
#nada sirve testear algo offline y que pase los test si eso no refleja el estado actual de la página. Además
#de no ser nada práctico.