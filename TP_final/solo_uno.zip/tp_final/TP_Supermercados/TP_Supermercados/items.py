from scrapy import Item, Field

class Producto(Item):
    supermercado = Field()
    marca=Field()
    producto=Field()
    categoria=Field()
    precio=Field()
    link=Field()
    hora=Field()
    fecha_de_extraccion=Field()
