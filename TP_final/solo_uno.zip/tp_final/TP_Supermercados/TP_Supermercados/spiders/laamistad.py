import string
import unicodedata
from datetime import datetime
from scrapy.loader import ItemLoader
from scrapy.spiders import CrawlSpider
from TP_Supermercados.TP_Supermercados.items import Producto


class LaamistadSpider(CrawlSpider):
    name = 'laamistad'
    busqueda = ''
    allowed_domains = ['tiendalaamistad.com.ar']

    def formatear(self,busqueda):
        busqueda = ''.join((c for c in unicodedata.normalize('NFD', busqueda) if unicodedata.category(c) != 'Mn'))
        for char in string.punctuation + "¡¿":
            busqueda = busqueda.replace(char, '')
        return busqueda.lower()

    def parse(self, response):
        producto = ItemLoader(Producto(), response)
        producto.add_value('supermercado', 'LA AMISTAD')
        producto.add_xpath('producto',
                           '/html/body/div[1]/div/div/div/main/div/div[1]/div[2]/div[1]/div/div[2]/div/h1/text()')
        producto.add_xpath('categoria',
                           '/html/body/div[1]/div/div/div/main/div/div[1]/div[2]/div[1]/div/div[2]/div/div[3]/span[2]/a[1]/text()')
        precio = response.xpath(

            '/html/body/div[1]/div/div/div/main/div/div[1]/div[2]/div[1]/div/div[2]/div/p[1]/span/text()').getall()[0]
        precio = '$' + precio
        producto.add_value('precio', precio)
        producto.add_value('link', response.url)
        producto.add_css('marca', '.woocommerce-product-attributes-item--attribute_pa_marca a::text')
        time = str(datetime.now().time().isoformat('seconds'))
        date = str(datetime.now().date())
        producto.add_value('fecha_de_extraccion', date)
        producto.add_value('hora', time)
        comparar = response.xpath(
            '/html/body/div[1]/div/div/div/main/div/div[1]/div[2]/div[1]/div/div[2]/div/h1/text()').getall()[0]
        comparar=self.formatear(comparar)
        return producto.load_item(), comparar

    def exacto(self, response):
        producto = self.parse(response)[0]
        resultado = self.parse(response)[1]
        if self.busqueda == resultado:
            yield producto

    def variable(self, response):
        producto = self.parse(response)[0]
        resultado = self.parse(response)[1].split(' ')
        contiene_alguna_palabra = False
        for palabra_busqueda in self.busqueda.split(' '):
            for palabra_resultado in resultado:
                if palabra_busqueda == palabra_resultado:
                    contiene_alguna_palabra = True
                    break
            if contiene_alguna_palabra:
                break
        if contiene_alguna_palabra:
            yield producto

    def todo(self, response):
        producto = self.parse(response)[0]
        resultado = self.parse(response)[1].split(" ")
        contiene_todo = True
        for palabra in self.busqueda.split(" "):
            if not resultado.__contains__(palabra):
                contiene_todo = False
                break
        if contiene_todo:
            yield producto