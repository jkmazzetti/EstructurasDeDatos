import string
import unicodedata
from datetime import datetime
from scrapy.loader import ItemLoader
from scrapy.spiders import CrawlSpider
from TP_Supermercados.TP_Supermercados.items import Producto


class WalmartSpider(CrawlSpider):

    name = 'walmart'
    busqueda = ''
    allowed_domains = ['walmart.com.ar']

    def formatear(self, busqueda):
        busqueda = ''.join((c for c in unicodedata.normalize('NFD', busqueda) if unicodedata.category(c) != 'Mn'))
        for char in string.punctuation + "¡¿":
            busqueda = busqueda.replace(char, '')
        return busqueda.lower()

    def parse(self, response):
        producto = ItemLoader(Producto(), response)
        producto.add_value("supermercado", self.name.upper())
        producto.add_xpath("producto", '/html/body/div[2]/div[1]/main/div/div[1]/div[2]/h1/div/text()')
        producto.add_xpath("categoria", '/html/body/div[2]/div[1]/main/div/div[1]/div[1]/ul/li[2]/a/span/text()')
        producto.add_xpath("precio", '/html/body/div[2]/div[1]/main/div/div[1]/div[4]/div[1]/p[1]/em[2]/strong/text()')
        producto.add_value("link", response.url)
        producto.add_xpath("marca", '/html/body/div[2]/div[1]/main/div/div[1]/div[2]/div[1]/div[1]/div/a/text()')
        time = str(datetime.now().time().isoformat('seconds'))
        date = str(datetime.now().date())
        producto.add_value('fecha_de_extraccion', date)
        producto.add_value('hora', time)
        comparar = response.xpath('/html/body/div[2]/div[1]/main/div/div[1]/div[2]/h1/div/text()').getall()[0]
        comparar = self.formatear(comparar)
        return producto.load_item(), comparar

    def variable(self, response):
        producto = self.parse(response)[0]
        resultado = self.parse(response)[1].split(' ')
        contiene_alguna_palabra = False
        for palabra_busqueda in self.busqueda.split(' '):
            for palabra_resultado in resultado:
                if palabra_busqueda == palabra_resultado:
                    contiene_alguna_palabra = True
                    break
            if contiene_alguna_palabra:
                break
        if contiene_alguna_palabra:
            yield producto

    def todo(self, response):
        producto = self.parse(response)[0]
        resultado = self.parse(response)[1].split(" ")
        contiene_todo = True
        for palabra in self.busqueda.split(" "):
            if not resultado.__contains__(palabra):
                contiene_todo = False
                break
        if contiene_todo:
            yield producto

    def exacto(self, response):
        producto = self.parse(response)[0]
        resultado = self.parse(response)[1]
        if self.busqueda == resultado:
            yield producto
