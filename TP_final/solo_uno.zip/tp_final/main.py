from TP_Supermercados.TP_Supermercados.Buscador.Buscador import Buscador
from TP_Supermercados.TP_Supermercados.Buscador.BuscadorExacto import BuscadorExacto
from TP_Supermercados.TP_Supermercados.Buscador.BuscadorTodo import BuscadorTodo
from TP_Supermercados.TP_Supermercados.Buscador.BuscadorVariable import BuscadorVariable
from TP_Supermercados.TP_Supermercados.spiders.dia import DiaSpider
from TP_Supermercados.TP_Supermercados.spiders.jumbo import JumboSpider
from TP_Supermercados.TP_Supermercados.spiders.laamistad import LaamistadSpider
from TP_Supermercados.TP_Supermercados.spiders.walmart import WalmartSpider


def main():

    aceptado = False
    print('¿Qué buscamos?')
    busqueda = BuscadorVariable.formatear(Buscador,str(input()))
    DiaSpider.busqueda = busqueda
    JumboSpider.busqueda = busqueda
    WalmartSpider.busqueda = busqueda
   # LaamistadSpider.busqueda = busqueda
    if busqueda!='':
        while not aceptado:
            print('¿En qué formato?\n1.CSV ordenado de menor a mayor.\n2.JSON crudo.')
            seleccion = int(input())
            if seleccion == 1:
                formato = 'csv'
                aceptado = True
            elif seleccion == 2:
                formato = 'json'
                aceptado = True
        aceptado = False
        while not aceptado:
            print('¿Qué tipo de busqueda?\n1.Producto con la descripcion exacta'
                  '\n2.Productos que contengan todas las palabras'
                  '\n3.Productos que contenga algunas de las palabras')
            seleccion = int(input())
            if seleccion == 1:
                aceptado = True
                nuevo_buscador=BuscadorExacto(busqueda,formato)
                nuevo_buscador.iniciar_busqueda()
                if formato=='csv':
                    nuevo_buscador.generar_archivo_ordenado_por_menor_precio()
            elif seleccion == 3:
                aceptado = True
                nuevo_buscador=BuscadorVariable(busqueda,formato)
                nuevo_buscador.iniciar_busqueda()
                if formato == 'csv':
                    nuevo_buscador.generar_archivo_ordenado_por_menor_precio()
            elif seleccion == 2:
                aceptado = True
                nuevo_buscador=BuscadorTodo(busqueda,formato)
                nuevo_buscador.iniciar_busqueda()
                if formato == 'csv':
                    nuevo_buscador.generar_archivo_ordenado_por_menor_precio()
    else:
        print('No buscamos nada, chau!')

if __name__ == '__main__':
    main()
